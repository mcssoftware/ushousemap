var MongoClient = require('mongodb').MongoClient,
    config = require('../configs/config.js'),
    utils = require('../libraries/util.js');

var state = {
    db: null
};

exports.connect = function (url, done) {
    url = url || '';
    var server = config.dbSettings.serverName;
    var port = config.dbSettings.serverPort;
    var dbName = config.dbSettings.databaseName;

    if (state.db) return done();
    console.log('[DB]  ' + utils.getDateTime().toString() + ' Attempting Connection to MongoDB');

    if (config.environment.sysEnv == 'development') {
        if (url == '') { url = 'mongodb://' + server + ':' + port + '/' + dbName; }

        MongoClient.connect(url, {
            db: {
                native_parser: false
            },
            server: {
                auto_reconnect: true,
                poolSize: 50
            },
            replSet: {},
            mongos: {}
        }, function (err, db) {
            if (err) return done(err);
            console.log('[DB]  ' + utils.getDateTime().toString() + ' Connected to MongoDB');
            state.db = db;
            done();
        });
    } else {
        if (url == '') {
            if (Array.isArray(config.dbSettings.serverName)) {
                var l = server.length;
                url = 'mongodb://' + config.dbSettings.username + ':' + config.dbSettings.password + '@';

                for (var i = 0; i < l; i++) {
                    url += server[i] + ':' + port[i];
                    if (i != l) url += ',';
                };

                url += '/' + dbName;
            }
        }

        console.log('[DB]  ' + utils.getDateTime().toString() + ' Authenticating with MongoDB');

        MongoClient.connect(url, {
            db: {
                native_parser: false
            },
            server: {
                auto_reconnect: true,
                poolSize: 50,
                ssl: true
            },
            replSet: {
                rs_name: config.dbSettings.replicaSetName
            },
            mongos: {}
        }, function (err, db) {
            if (err) return done(err);
            console.log('[DB]  ' + utils.getDateTime().toString() + ' Connected to MongoDB');
            state.db = db;
            done();
        });
    }
};

exports.get = function () {
    return state.db;
};

exports.close = function (done) {
    if (state.db) {
        state.db.close(function (err, result) {
            state.db = null;
            state.mode = null;
            done(err);
        });
    }
};