var newrelic = require('newrelic');
var MongoConnection = require('./api/dbConnection'),
    config = require('./configs/config.js'),
    express = require('express'),
    compression = require("compression"),
    routes = require('./routes/endpointsSecured'),
    app = express(),
    port = process.env.PORT,
    utils = require('./libraries/util.js');

process.setMaxListeners(0);
process.env.NODE_ENV = config.environment.sysEnv;
app.set('query parser', 'simple');
app.use(compression());
app.locals.newrelic = newrelic;

app.use('/', routes);

// ### Error Catching
app.use(function (err, req, res, next) {
    if (config.environment.sysEnv != "development") {
        if (err) {
            console.error(err);
            res.redirect('/Error/500');
        }
    } else {
        next(err);
    }
});

// ### Connect to DB & Start App
// --> MongoConnection URL is blank, provide MongoURL to OVERRIDE ONLY
MongoConnection.connect('', function (err) {
    if (err) {
        console.error(err);
        process.exit(1);
    } else {
        if (config.global.enablePM2 == true) {
            var pm2 = require('pm2');

            pm2.connect(function (err) {
                if (err) {
                    console.error(err);
                    process.exit(2);
                }

                pm2.start({
                    script: 'app.js',           // Script to be run
                    exec_mode: 'cluster',       // Allows your app to be clustered
                    instances: 2,               // Optional: Scales your app by 2
                    max_memory_restart: '100M'  // Optional: Restarts your app if it reaches 100Mo
                }, function (err, apps) {
                    pm2.disconnect();           // Disconnects from PM2

                    if (err) {
                        throw err;
                    }
                });
            });
        }

        app.listen(port, (err) => { console.log("[START]  " + utils.getDateTime().toString() + " Node is running on port " + port); });
    }
});