/// <reference path="globals/node/index.d.ts" />
