﻿module.exports = {
    logError: function (httpCode, errorMessage, stackTrace) {
        
    }
};